$(document).ready(function(){
	new Marquee("Marquee",2,2,950,175,50,0,1000,-2);

});
  