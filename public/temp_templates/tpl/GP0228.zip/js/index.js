jQuery(document).ready(function($) {
	
// ��ҳ����չʾ
	jQuery(".casimg").slide({mainCell:".scrcont ul",autoPage:true,effect:"left",autoPlay:true});

//��ҳ��Ʒչʾ
	jQuery(".showpro").slide({mainCell:"ul",autoPlay:true,effect:"leftMarquee",vis:4,interTime:25});
});


