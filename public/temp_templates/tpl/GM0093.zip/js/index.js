$(document).ready(function(){


	var swiper = new Swiper('.banner.swiper-container', {
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        centeredSlides: true,
        autoplay: 2500,
        autoplayDisableOnInteraction: false
    });
// 菜单
 var swiper = new Swiper('.menu.swiper-container', {
        pagination: '.swiper-pagination',
        paginationClickable: true
    });



  });