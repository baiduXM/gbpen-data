jQuery(document).ready(function($) {
    //首页导航切换
    var swiper = new Swiper('.hd .swiper-container', {
        pagination: '.page',
        paginationClickable: true,
        spaceBetween: 30,
    });
        var swiper = new Swiper('.mune.swiper-container', {
        pagination: '.swiper-pagination',
        paginationClickable: true,
        spaceBetween: 30,
        slidesPerView: 4,
        
    });
    var swiper = new Swiper('.products_detail .swiper-container', {
        pagination: '.swiper-pagination',
        paginationClickable: true,
        spaceBetween: 30,
    });

});