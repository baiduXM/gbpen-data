$(document).ready(function(){

// 菜单
 var swiper = new Swiper('.aboutment.swiper-container', {
         nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        paginationClickable: true
    });



  });