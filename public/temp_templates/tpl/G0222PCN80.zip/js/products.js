$(document).ready(function() {

	addLoadEvent(Focus());

});